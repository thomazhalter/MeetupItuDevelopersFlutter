//
//  Generated file. Do not edit.
//
import Foundation
import FlutterMacOS

import color_panel
import example_plugin
import file_chooser
import menubar
import path_provider_fde
import shared_preferences_fde
import url_launcher_fde
import window_size

func RegisterGeneratedPlugins(registry: FlutterPluginRegistry) {
  ColorPanelPlugin.register(with: registry.registrar(forPlugin: "ColorPanelPlugin"))
  ExamplePlugin.register(with: registry.registrar(forPlugin: "ExamplePlugin"))
  FileChooserPlugin.register(with: registry.registrar(forPlugin: "FileChooserPlugin"))
  MenubarPlugin.register(with: registry.registrar(forPlugin: "MenubarPlugin"))
  PathProviderPlugin.register(with: registry.registrar(forPlugin: "PathProviderPlugin"))
  SharedPreferencesPlugin.register(with: registry.registrar(forPlugin: "SharedPreferencesPlugin"))
  UrlLauncherPlugin.register(with: registry.registrar(forPlugin: "UrlLauncherPlugin"))
  WindowSizePlugin.register(with: registry.registrar(forPlugin: "WindowSizePlugin"))
}
