---
name: Other
about: Request unrelated to a bug
title: ''
labels: ''
assignees: ''

---

<!--
*** Important Note ***
Development of Flutter for Desktop is now primarily happening in the Flutter repository itself. If you have a bug or feature request related to desktop that's about the Flutter framework, the `flutter` command-line tool, or the desktop support in the Flutter engine, please file your bug in the Flutter issue tracker: https://github.com/flutter/flutter/issues

Please file bugs here only for things specific to this repository, such as:
* Proposed changes to instructions in the READMEs here.
* Requests specific to the plugins here.

If you're not sure whether the report belongs here or in Flutter itself, you can file it here here, but we may close the issue and ask you to file it in Flutter if it turns out not to be specific to this project.

***Important Note #2***
For general discussion and questions, please use the project mailing list rather than filing an issue:
https://groups.google.com/forum/#!forum/flutter-desktop-embedding-dev
-->

**Describe Request**
