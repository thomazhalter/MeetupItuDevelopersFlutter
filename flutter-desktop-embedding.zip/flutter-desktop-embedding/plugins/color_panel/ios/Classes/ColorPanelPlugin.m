#import "ColorPanelPlugin.h"

@implementation ColorPanelPlugin
+ (void)registerWithRegistrar:(NSObject<FlutterPluginRegistrar>*)registrar {}

@end
