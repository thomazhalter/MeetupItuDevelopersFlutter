#import <Flutter/Flutter.h>

@interface ConnectivityPlugin : NSObject<FlutterPlugin>
@end
