#import "ConnectivityPlugin.h"

@implementation ConnectivityPlugin
+ (void)registerWithRegistrar:(NSObject<FlutterPluginRegistrar>*)registrar {}

@end
