#import "WindowSizePlugin.h"

@implementation WindowSizePlugin
+ (void)registerWithRegistrar:(NSObject<FlutterPluginRegistrar>*)registrar {}

@end
